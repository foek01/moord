import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export interface GeneratedStory {
  title: string;
  story: string;
  characters: Character[];
}

export interface Character {
  name: string;
  role: string;
  description: string;
  isMurderer?: boolean;
  isVictim?: boolean;
}

export async function generateMysteryStory(gameTitle: string, playerCount: number): Promise<GeneratedStory> {
  const prompt = `Create a murder mystery story for a game titled "${gameTitle}" with ${playerCount} players.
    Include:
    1. A compelling murder mystery narrative
    2. ${playerCount} unique characters (including 1 murderer and 1 victim)
    Each character should have a name, role, and brief description.
    Format the response as JSON with the following structure:
    {
      "title": "string",
      "story": "string",
      "characters": [
        {
          "name": "string",
          "role": "string",
          "description": "string",
          "isMurderer": boolean,
          "isVictim": boolean
        }
      ]
    }`;

  try {
    const completion = await openai.chat.completions.create({
      messages: [{ role: "user", content: prompt }],
      model: "gpt-3.5-turbo",
      temperature: 0.7,
      max_tokens: 2000,
    });

    const response = completion.choices[0].message.content;
    return JSON.parse(response || '{}');
  } catch (error) {
    console.error('Error generating story:', error);
    throw new Error('Failed to generate mystery story');
  }
}