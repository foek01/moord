import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronRight, Users, Clock, Star, Check } from 'lucide-react';
import { games } from '../data/games';
import { useCart } from '../context/CartContext';
import Modal from '../components/shared/Modal';

export default function GameDetail() {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [showModal, setShowModal] = useState(false);
  const [quantity, setQuantity] = useState(1);

  const game = games.find(g => g.id === gameId);

  if (!game) {
    return (
      <div className="container mx-auto px-4 py-20 text-center text-white">
        <h1 className="text-3xl font-bold mb-4">Game Not Found</h1>
        <button 
          onClick={() => navigate('/')}
          className="text-[#FF4136] hover:underline"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({ ...game, quantity });
    setShowModal(true);
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="relative h-[60vh] bg-cover bg-center" style={{ backgroundImage: `url(${game.image})` }}>
        <div className="absolute inset-0 bg-black bg-opacity-60" />
        <div className="container mx-auto px-4 h-full flex items-center relative">
          <div className="text-white">
            <div className="flex items-center space-x-2 text-sm mb-4">
              <a href="/" className="hover:text-[#FF4136]">Home</a>
              <ChevronRight className="w-4 h-4" />
              <a href="/games" className="hover:text-[#FF4136]">Games</a>
              <ChevronRight className="w-4 h-4" />
              <span>{game.title}</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4">{game.title}</h1>
            <p className="text-xl max-w-2xl">{game.description}</p>
          </div>
        </div>
      </div>

      {/* Game Details */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-[#4A4A4A] rounded-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">About This Game</h2>
              <p className="text-gray-300 whitespace-pre-line">{game.longDescription}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-[#4A4A4A] rounded-lg p-8">
                <h3 className="text-xl font-bold text-white mb-4">What's Included</h3>
                <ul className="space-y-3">
                  {game.includes.map((item, index) => (
                    <li key={index} className="flex items-start text-gray-300">
                      <Check className="w-5 h-5 text-[#FF4136] mr-2 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#4A4A4A] rounded-lg p-8">
                <h3 className="text-xl font-bold text-white mb-4">Requirements</h3>
                <ul className="space-y-3">
                  {game.requirements.map((item, index) => (
                    <li key={index} className="flex items-start text-gray-300">
                      <Check className="w-5 h-5 text-[#FF4136] mr-2 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-[#4A4A4A] rounded-lg p-8 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2 text-gray-300">
                  <Users className="w-5 h-5" />
                  <span>{game.players} players</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-300">
                  <Clock className="w-5 h-5" />
                  <span>{game.duration}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-300">
                  <Star className="w-5 h-5 text-[#FF4136]" />
                  <span>{game.rating}</span>
                </div>
              </div>

              <div className="text-center mb-6">
                <span className="text-3xl font-bold text-white">${game.price}</span>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Quantity
                </label>
                <select
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-[#2A2A2A] text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#FF4136]"
                >
                  {[1, 2, 3, 4, 5].map(num => (
                    <option key={num} value={num}>{num}</option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleAddToCart}
                className="w-full bg-[#FF4136] text-white py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Added to Cart Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Added to Cart"
      >
        <div className="text-white">
          <p className="mb-4">{game.title} has been added to your cart.</p>
          <div className="flex justify-end space-x-4">
            <button
              onClick={() => setShowModal(false)}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors"
            >
              Continue Shopping
            </button>
            <button
              onClick={() => navigate('/cart')}
              className="px-4 py-2 bg-[#FF4136] text-white rounded-lg hover:bg-opacity-90 transition-colors"
            >
              View Cart
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}