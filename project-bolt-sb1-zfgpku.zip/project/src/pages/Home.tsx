import React from 'react';
import Hero from '../components/home/Hero';
import FeaturedGames from '../components/home/FeaturedGames';
import HowItWorks from '../components/home/HowItWorks';
import FAQ from '../components/home/FAQ';

export default function Home() {
  return (
    <>
      <Hero />
      <FeaturedGames />
      <HowItWorks />
      <FAQ />
    </>
  );
}