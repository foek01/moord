import React from 'react';
import { useLocation, Navigate } from 'react-router-dom';
import type { GeneratedStory, Character } from '../services/openai';

export default function Story() {
  const location = useLocation();
  const story = location.state?.story as GeneratedStory;

  if (!story) {
    return <Navigate to="/" replace />;
  }

  const murderer = story.characters.find(char => char.isMurderer);
  const victim = story.characters.find(char => char.isVictim);
  const otherCharacters = story.characters.filter(char => !char.isMurderer && !char.isVictim);

  return (
    <div className="min-h-screen pt-16 bg-[#2A2A2A] text-white">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-center">{story.title}</h1>

        <div className="max-w-4xl mx-auto">
          {/* Story Section */}
          <div className="bg-[#4A4A4A] rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold mb-4">The Story</h2>
            <p className="whitespace-pre-line text-gray-300">{story.story}</p>
          </div>

          {/* Characters Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Murderer Card */}
            {murderer && (
              <div className="bg-[#4A4A4A] rounded-lg p-6 border-2 border-[#FF4136]">
                <h3 className="text-xl font-bold mb-2 text-[#FF4136]">The Murderer</h3>
                <p className="font-bold mb-1">{murderer.name}</p>
                <p className="text-sm text-gray-400 mb-2">{murderer.role}</p>
                <p className="text-gray-300">{murderer.description}</p>
              </div>
            )}

            {/* Victim Card */}
            {victim && (
              <div className="bg-[#4A4A4A] rounded-lg p-6 border-2 border-gray-500">
                <h3 className="text-xl font-bold mb-2 text-gray-400">The Victim</h3>
                <p className="font-bold mb-1">{victim.name}</p>
                <p className="text-sm text-gray-400 mb-2">{victim.role}</p>
                <p className="text-gray-300">{victim.description}</p>
              </div>
            )}
          </div>

          {/* Other Characters */}
          <h2 className="text-2xl font-bold mt-12 mb-6">Other Characters</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {otherCharacters.map((character, index) => (
              <div key={index} className="bg-[#4A4A4A] rounded-lg p-6">
                <p className="font-bold mb-1">{character.name}</p>
                <p className="text-sm text-gray-400 mb-2">{character.role}</p>
                <p className="text-gray-300">{character.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}