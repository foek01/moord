import React from 'react';
import { Play } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center text-white">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?auto=format&fit=crop&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Solve the Mystery,<br />
          <span className="text-[#FF4136]">Live the Adventure</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
          Immerse yourself in our interactive murder mystery experiences. 
          Perfect for parties, team building, or unforgettable nights out.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <a 
            href="/games"
            className="bg-[#FF4136] text-white px-8 py-3 rounded-full font-semibold hover:bg-opacity-90 transition-colors inline-flex items-center space-x-2"
          >
            <span>Browse Games</span>
          </a>
          
          <button 
            className="bg-transparent border-2 border-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-[#2A2A2A] transition-colors inline-flex items-center space-x-2"
          >
            <Play className="w-5 h-5" />
            <span>Watch Trailer</span>
          </button>
        </div>
      </div>
    </div>
  );
}