import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  {
    question: 'How many players do I need for a game?',
    answer: 'Our games are designed for different group sizes, typically ranging from 6 to 20 players. Each game specifies its minimum and maximum player count to ensure the best experience.'
  },
  {
    question: 'How long does a typical game last?',
    answer: 'Most of our murder mystery games run between 2-4 hours, depending on the specific game and your group\'s pace. The duration is perfect for an evening of entertainment.'
  },
  {
    question: 'What materials are included with purchase?',
    answer: 'Each game includes a complete digital package with character descriptions, clues, evidence, host instructions, and all necessary printable materials. Some games also include optional digital props and themed music.'
  },
  {
    question: 'Do we need to dress up in costumes?',
    answer: 'While costumes are not required, they can enhance the experience. Each game includes costume suggestions, but players can participate fully without them.'
  },
  {
    question: 'Can I reuse the game with different players?',
    answer: 'While the solution remains the same, our games can be played multiple times with different groups. However, players who know the solution should take different roles in subsequent playthroughs.'
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-20 bg-[#2A2A2A]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
          Frequently Asked Questions
        </h2>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-[#4A4A4A] rounded-lg overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 flex items-center justify-between text-white hover:text-[#FF4136] transition-colors"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="font-semibold text-left">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="w-5 h-5 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 flex-shrink-0" />
                )}
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-4 text-gray-300">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}