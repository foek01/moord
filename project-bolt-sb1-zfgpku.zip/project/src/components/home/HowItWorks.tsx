import React from 'react';
import { BookOpen, Users, PlayCircle, Award } from 'lucide-react';

const steps = [
  {
    icon: BookOpen,
    title: 'Choose Your Mystery',
    description: 'Browse our selection of immersive murder mystery games and select the perfect scenario for your group.'
  },
  {
    icon: Users,
    title: 'Gather Your Team',
    description: 'Invite your friends, family, or colleagues. Each game has a recommended number of players for the best experience.'
  },
  {
    icon: PlayCircle,
    title: 'Start the Adventure',
    description: 'Receive your digital game pack with all materials, assign roles, and begin your investigation.'
  },
  {
    icon: Award,
    title: 'Solve the Case',
    description: 'Work together, analyze clues, and use your detective skills to uncover the truth and catch the killer!'
  }
];

export default function HowItWorks() {
  return (
    <section className="py-20 bg-[#4A4A4A]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
          How It Works
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-[#FF4136] rounded-full flex items-center justify-center mb-4">
                <step.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
              <p className="text-gray-300">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}