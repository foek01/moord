import React from 'react';
import { Users, Clock, Star } from 'lucide-react';

interface Game {
  id: string;
  title: string;
  description: string;
  image: string;
  players: string;
  duration: string;
  rating: number;
  price: number;
}

const games: Game[] = [
  {
    id: 'mansion-murder',
    title: 'Mansion Murder',
    description: 'A classic whodunit set in a Victorian mansion. Can you solve the murder of Lord Blackwood?',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80',
    players: '6-12',
    duration: '2-3 hours',
    rating: 4.8,
    price: 299
  },
  {
    id: 'cruise-crime',
    title: 'Cruise Crime',
    description: 'Murder on the high seas! Investigate a mysterious death aboard a luxury cruise liner.',
    image: 'https://images.unsplash.com/photo-1599640842225-85d111c60e6b?auto=format&fit=crop&q=80',
    players: '8-15',
    duration: '2-4 hours',
    rating: 4.9,
    price: 349
  },
  {
    id: 'castle-conspiracy',
    title: 'Castle Conspiracy',
    description: 'Unravel dark secrets in an ancient castle. A modern mystery with medieval twists.',
    image: 'https://images.unsplash.com/photo-1585543805890-6051f7829f98?auto=format&fit=crop&q=80',
    players: '10-20',
    duration: '3-4 hours',
    rating: 4.7,
    price: 399
  }
];

export default function FeaturedGames() {
  return (
    <section className="py-20 bg-[#2A2A2A]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
          Featured Murder Mysteries
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {games.map((game) => (
            <div 
              key={game.id}
              className="bg-[#4A4A4A] rounded-lg overflow-hidden hover:transform hover:scale-105 transition-transform duration-300"
            >
              <div className="relative h-48">
                <img 
                  src={game.image} 
                  alt={game.title}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{game.title}</h3>
                <p className="text-gray-300 mb-4">{game.description}</p>

                <div className="flex items-center justify-between text-sm text-gray-300 mb-4">
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{game.players} players</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{game.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-[#FF4136]" />
                    <span>{game.rating}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-white">${game.price}</span>
                  <a
                    href={`/games/${game.id}`}
                    className="bg-[#FF4136] text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-opacity-90 transition-colors"
                  >
                    Learn More
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}