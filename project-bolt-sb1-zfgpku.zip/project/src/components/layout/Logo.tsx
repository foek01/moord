import React from 'react';
import { Skull } from 'lucide-react';

export default function Logo() {
  return (
    <a href="/" className="flex items-center space-x-2 text-white hover:text-[#FF4136] transition-colors">
      <Skull className="w-8 h-8" />
      <span className="text-xl font-bold">Murder Mystery Co.</span>
    </a>
  );
}