import React from 'react';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#2A2A2A] text-white mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Murder Mystery Co.</h3>
            <p className="text-sm text-gray-400">
              Creating unforgettable murder mystery experiences since 2024.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="/about" className="hover:text-[#FF4136] transition-colors">About Us</a></li>
              <li><a href="/games" className="hover:text-[#FF4136] transition-colors">Our Games</a></li>
              <li><a href="/blog" className="hover:text-[#FF4136] transition-colors">Blog</a></li>
              <li><a href="/careers" className="hover:text-[#FF4136] transition-colors">Careers</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="/contact" className="hover:text-[#FF4136] transition-colors">Contact Us</a></li>
              <li><a href="/faq" className="hover:text-[#FF4136] transition-colors">FAQ</a></li>
              <li><a href="/privacy" className="hover:text-[#FF4136] transition-colors">Privacy Policy</a></li>
              <li><a href="/terms" className="hover:text-[#FF4136] transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="hover:text-[#FF4136] transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="https://twitter.com" className="hover:text-[#FF4136] transition-colors">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="https://instagram.com" className="hover:text-[#FF4136] transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="https://youtube.com" className="hover:text-[#FF4136] transition-colors">
                <Youtube className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-[#4A4A4A] mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} Murder Mystery Co. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}