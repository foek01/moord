import React, { useState } from 'react';
import { Menu, X, ShoppingCart, Search } from 'lucide-react';
import Logo from './Logo';
import Navigation from './Navigation';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  return (
    <header className="fixed top-0 w-full bg-[#2A2A2A] text-white shadow-lg z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Logo />
          
          <div className="hidden md:flex items-center space-x-8">
            <Navigation />
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 hover:text-[#FF4136] transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 hover:text-[#FF4136] transition-colors relative">
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#FF4136] text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
              className="md:hidden p-2 hover:text-[#FF4136] transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-[#2A2A2A] border-t border-[#4A4A4A]">
          <div className="container mx-auto px-4 py-4">
            <Navigation mobile />
          </div>
        </div>
      )}
    </header>
  );
}