import React from 'react';
import { ChevronDown } from 'lucide-react';

interface NavigationProps {
  mobile?: boolean;
}

export default function Navigation({ mobile = false }: NavigationProps) {
  const baseStyles = mobile
    ? "flex flex-col space-y-4"
    : "flex items-center space-x-8";

  return (
    <nav className={baseStyles}>
      <a href="/" className="text-white hover:text-[#FF4136] transition-colors">Home</a>
      
      <div className="relative group">
        <button className="flex items-center space-x-1 text-white hover:text-[#FF4136] transition-colors">
          <span>Murder Games</span>
          <ChevronDown className="w-4 h-4" />
        </button>
        
        <div className={`${mobile ? 'mt-2' : 'absolute top-full left-0 mt-2 hidden group-hover:block'} bg-[#2A2A2A] border border-[#4A4A4A] rounded-md min-w-[200px]`}>
          <a href="/games/mansion-murder" className="block px-4 py-2 hover:bg-[#4A4A4A] text-white hover:text-[#FF4136] transition-colors">
            Mansion Murder
          </a>
          <a href="/games/cruise-crime" className="block px-4 py-2 hover:bg-[#4A4A4A] text-white hover:text-[#FF4136] transition-colors">
            Cruise Crime
          </a>
          <a href="/games/castle-conspiracy" className="block px-4 py-2 hover:bg-[#4A4A4A] text-white hover:text-[#FF4136] transition-colors">
            Castle Conspiracy
          </a>
        </div>
      </div>

      <a href="/how-it-works" className="text-white hover:text-[#FF4136] transition-colors">How It Works</a>
      <a href="/faq" className="text-white hover:text-[#FF4136] transition-colors">FAQ</a>
      <a href="/contact" className="text-white hover:text-[#FF4136] transition-colors">Contact</a>
    </nav>
  );
}