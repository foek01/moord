import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from '../shared/Modal';
import { generateMysteryStory } from '../../services/openai';
import type { CartItem } from '../../types/game';
import type { GeneratedStory } from '../../services/openai';

interface PlayerInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onComplete: (story: GeneratedStory) => void;
}

export default function PlayerInfoModal({ isOpen, onClose, cartItems, onComplete }: PlayerInfoModalProps) {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [playerCount, setPlayerCount] = useState<number>(6);
  const [playerNames, setPlayerNames] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePlayerCountSubmit = () => {
    setPlayerNames(Array(playerCount).fill(''));
    setStep(2);
  };

  const handlePlayerNamesChange = (index: number, name: string) => {
    const newNames = [...playerNames];
    newNames[index] = name;
    setPlayerNames(newNames);
  };

  const handleGenerateStory = async () => {
    setIsGenerating(true);
    setError(null);

    try {
      const stories = await Promise.all(
        cartItems.map(item => generateMysteryStory(item.title, playerCount))
      );
      
      onComplete(stories[0]); // For now, we'll just use the first story
      onClose();
      navigate('/story');
    } catch (err) {
      setError('Failed to generate story. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={step === 1 ? "Number of Players" : "Player Names"}
    >
      <div className="text-white">
        {step === 1 && (
          <div className="space-y-4">
            <p className="mb-4">How many players will be participating?</p>
            <select
              value={playerCount}
              onChange={(e) => setPlayerCount(Number(e.target.value))}
              className="w-full bg-[#2A2A2A] text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#FF4136]"
            >
              {[6, 7, 8, 9, 10, 11, 12].map(num => (
                <option key={num} value={num}>{num} Players</option>
              ))}
            </select>
            <button
              onClick={handlePlayerCountSubmit}
              className="w-full bg-[#FF4136] text-white py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors"
            >
              Continue
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <p className="mb-4">Enter the names of all players:</p>
            <div className="max-h-[400px] overflow-y-auto space-y-2">
              {playerNames.map((name, index) => (
                <input
                  key={index}
                  type="text"
                  value={name}
                  onChange={(e) => handlePlayerNamesChange(index, e.target.value)}
                  placeholder={`Player ${index + 1}`}
                  className="w-full bg-[#2A2A2A] text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#FF4136]"
                />
              ))}
            </div>
            {error && (
              <p className="text-red-400 text-sm">{error}</p>
            )}
            <button
              onClick={handleGenerateStory}
              disabled={isGenerating || playerNames.some(name => !name.trim())}
              className="w-full bg-[#FF4136] text-white py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Generating Story...' : 'Generate Story'}
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
}