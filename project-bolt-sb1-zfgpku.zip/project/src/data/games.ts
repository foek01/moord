import { Game } from '../types/game';

export const games: Game[] = [
  {
    id: 'mansion-murder',
    title: 'Mansion Murder',
    description: 'A classic whodunit set in a Victorian mansion. Can you solve the murder of Lord Blackwood?',
    longDescription: `Step into the shoes of a detective in this thrilling Victorian-era murder mystery. Lord Blackwood has been found dead in his study, and everyone in the mansion is a suspect. As you explore the grand halls and hidden passages, you'll uncover dark secrets, examine evidence, and interrogate suspects to solve this classic whodunit.

This immersive experience combines period-accurate details with modern storytelling techniques, creating an unforgettable night of mystery and intrigue. Perfect for large groups and special occasions, Mansion Murder will test your detective skills and challenge your deductive reasoning.`,
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80',
    players: '6-12',
    duration: '2-3 hours',
    rating: 4.8,
    price: 299,
    includes: [
      'Full game script and materials',
      'Character dossiers',
      'Evidence packets',
      'Digital props and clues',
      'Host guide with detailed instructions',
      'Victorian-era costume suggestions',
      'Soundtrack and ambient music'
    ],
    requirements: [
      'Minimum 6 players',
      'Space for movement and exploration',
      'Basic props (easily found household items)',
      'Printing capabilities for materials',
      '2-3 hours of dedicated play time'
    ]
  },
  {
    id: 'cruise-crime',
    title: 'Cruise Crime',
    description: 'Murder on the high seas! Investigate a mysterious death aboard a luxury cruise liner.',
    longDescription: `Set sail for adventure and danger aboard the SS Luminous, a luxury cruise liner where a mysterious death has occurred. As passengers and crew members, you'll navigate through the ship's various decks, from the glamorous ballroom to the secretive crew quarters, piecing together clues about what really happened on this fateful voyage.

This contemporary mystery features modern forensic techniques alongside traditional detective work, creating a unique and engaging experience for all players. With multiple possible outcomes based on your group's decisions, no two games will be exactly alike.`,
    image: 'https://images.unsplash.com/photo-1599640842225-85d111c60e6b?auto=format&fit=crop&q=80',
    players: '8-15',
    duration: '2-4 hours',
    rating: 4.9,
    price: 349,
    includes: [
      'Complete game materials',
      'Digital ship layouts',
      'Character backgrounds',
      'Modern forensic evidence files',
      'Detailed facilitator guide',
      'Digital props and sound effects',
      'Optional costume suggestions'
    ],
    requirements: [
      'Minimum 8 players',
      'Large room or multiple connected spaces',
      'Basic props (common household items)',
      'Ability to play audio',
      'Printing capabilities',
      '2-4 hours of play time'
    ]
  },
  {
    id: 'castle-conspiracy',
    title: 'Castle Conspiracy',
    description: 'Unravel dark secrets in an ancient castle. A modern mystery with medieval twists.',
    longDescription: `Welcome to Castle Ravencrest, where ancient stones hold modern secrets. This unique mystery blends medieval atmosphere with contemporary intrigue, as players work to solve a murder that has roots in centuries-old legends. The castle's various chambers and towers become your playground as you search for clues, decode ancient symbols, and uncover a conspiracy that spans generations.

Perfect for larger groups, this game features multiple interweaving plotlines that keep all players engaged throughout the experience. With elements of historical investigation alongside modern detective work, Castle Conspiracy offers a unique twist on the traditional murder mystery format.`,
    image: 'https://images.unsplash.com/photo-1585543805890-6051f7829f98?auto=format&fit=crop&q=80',
    players: '10-20',
    duration: '3-4 hours',
    rating: 4.7,
    price: 399,
    includes: [
      'Full game materials and scripts',
      'Castle map and location cards',
      'Historical documents and modern evidence',
      'Character profiles and backgrounds',
      'Medieval-themed props list',
      'Comprehensive host guide',
      'Themed music playlist',
      'Optional costume guidelines'
    ],
    requirements: [
      'Minimum 10 players',
      'Large space with multiple rooms',
      'Basic props and decorations',
      'Audio playback capability',
      'Printing facilities',
      '3-4 hours of dedicated play time'
    ]
  }
];