export interface Game {
  id: string;
  title: string;
  description: string;
  image: string;
  players: string;
  duration: string;
  rating: number;
  price: number;
  longDescription: string;
  includes: string[];
  requirements: string[];
}

export interface CartItem extends Game {
  quantity: number;
}